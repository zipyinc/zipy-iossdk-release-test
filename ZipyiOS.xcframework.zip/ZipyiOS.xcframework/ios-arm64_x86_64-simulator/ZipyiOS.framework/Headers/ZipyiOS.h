//
//  ZipyiOS.h
//  ZipyiOS
//
//  Created by Sandesh Murdia on 09/04/25.
//

#import <Foundation/Foundation.h>

//! Project version number for ZipyiOS.
FOUNDATION_EXPORT double ZipyiOSVersionNumber;

//! Project version string for ZipyiOS.
FOUNDATION_EXPORT const unsigned char ZipyiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZipyiOS/PublicHeader.h>


